package de.akquinet.innovation.osgi;

public interface HelloService {

    public String sayHello();

    public String sayHello(String name);

}
