/*
 * DeveloperWorks Native Memory Article Sample Code
 * (C) Copyright IBM Corp. 2008. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or
 * disclosure restricted by GSA ADP Schedule Contract with
 * IBM Corp.
 */

#include <stdlib.h>
#include <stdio.h>
#include <jni.h>

#define INITIAL_ALLOCATION_SIZE_BYTES (512 * 1024 * 1024)
#define BYTES_TO_LEAVE (10 * 1024)

const char copyright[] = "(C) Copyright IBM Corp. 2008. All Rights Reserved. \
US Government Users Restricted Rights - Use, duplication or \
disclosure restricted by GSA ADP Schedule Contract with \
IBM Corp. ";
 

JNIEXPORT void JNICALL Java_com_ibm_jtc_demos_NativeMemoryGlutton_gobbleMemory
  (JNIEnv * env, jclass clazz)
{
	size_t allocation_size = INITIAL_ALLOCATION_SIZE_BYTES;
	unsigned int total_allocated = 0;
	
	while(allocation_size > BYTES_TO_LEAVE)
	{
		void * ptr = malloc(allocation_size);
		
		if(NULL == ptr)
		{
			allocation_size = allocation_size / 2;	
		}
		else
		{
			total_allocated += allocation_size;	
		}
	}
	
	fprintf(stderr,"Allocated %u bytes of native memory before running out\n",total_allocated);
}

