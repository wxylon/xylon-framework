#
# DeveloperWorks Native Memory Article Sample Code
# (C) Copyright IBM Corp. 2008. All Rights Reserved.
#
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with
# IBM Corp.
#

# Linux 390 31 run script for com.ibm.jtc.demos.DirectByteBufferUnderNativeStarvation testcase
# Expects JAVA_HOME environment variable to be set such that $JAVA_HOME/jre/bin/java is a Java launcher.
# Should be run from within the LeakyJNIApp directory (the script makes assumptions about relative paths).
# Andrew Hall
# andhall@uk.ibm.com

$JAVA_HOME/jre/bin/java -Djava.library.path=binaries/linux_390_31 com.ibm.jtc.demos.DirectByteBufferUnderNativeStarvation

