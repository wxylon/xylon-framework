/*
 * DeveloperWorks Native Memory Article Sample Code
 * (C) Copyright IBM Corp. 2008. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or
 * disclosure restricted by GSA ADP Schedule Contract with
 * IBM Corp.
 */
package com.ibm.jtc.demos;

/**
 * A utility class that has a native component capable of consuming 
 * all the native memory in the process.
 *
 * @author <a href="mailto:andhall@uk.ibm.com">Andrew Hall</a>
 *
 */
public class NativeMemoryGlutton
{
    
    static
    {
        System.loadLibrary("nativememoryglutton");
    }
    
    /**
     * Irretrievably allocates all of the native virtual memory in the 
     * address space. 
     */
    public static native void gobbleMemory();

    final String copyright = "(C) Copyright IBM Corp. 2008. All Rights Reserved. US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.";

}
