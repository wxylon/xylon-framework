/*
 * DeveloperWorks Native Memory Article Sample Code
 * (C) Copyright IBM Corp. 2008. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or
 * disclosure restricted by GSA ADP Schedule Contract with
 * IBM Corp.
 */
package com.ibm.jtc.demos;

import java.nio.ByteBuffer;

/**
 * Testcase that attempts to allocate a direct bytebuffer with an exhausted
 * process address space.
 *
 * @author <a href="mailto:andhall@uk.ibm.com">Andrew Hall</a>
 *
 */
public class DirectByteBufferUnderNativeStarvation
{

    public static void main(String[] args)
    {
        NativeMemoryGlutton.gobbleMemory();
        
        ByteBuffer.allocateDirect(1024 * 1024);
    }

    final String copyright = "(C) Copyright IBM Corp. 2008. All Rights Reserved. US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.";

}
