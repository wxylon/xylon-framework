#!/bin/sh

#DeveloperWorks Native Memory Article Sample Code
#(C) Copyright IBM Corp. 2008. All Rights Reserved.
#US Government Users Restricted Rights - Use, duplication or
#disclosure restricted by GSA ADP Schedule Contract with
#IBM Corp.

#Linux build script for LeakJNIApp
#Expects gcc and ld to be on the PATH 
#
#Expected the JAVA_HOME environment variable to be
#set such that $JAVA_HOME/bin/javac is the Java compiler
#and $JAVA_HOME/include contains the Java JNI header files
#Andrew Hall

#Build the Java
$JAVA_HOME/bin/javac -d . com/ibm/jtc/demos/LeakyJNIApp.java

#Create the JNI Header
$JAVA_HOME/bin/javah com.ibm.jtc.demos.LeakyJNIApp

#Compile the C source
CFLAGS="-I $JAVA_HOME/include -g -fPIC"

gcc $CFLAGS -c LeakyJNIApp.c

#Build the DLL

export LFLAGS="-shared -o binaries/linux_ppc32/libleakyjniapp.so"

ld $LFLAGS LeakyJNIApp.o
