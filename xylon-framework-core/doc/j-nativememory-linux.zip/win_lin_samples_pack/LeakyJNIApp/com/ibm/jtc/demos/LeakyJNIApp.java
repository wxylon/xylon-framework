/*
 * DeveloperWorks Native Memory Article Sample Code
 * (C) Copyright IBM Corp. 2008. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or
 * disclosure restricted by GSA ADP Schedule Contract with
 * IBM Corp.
 */
package com.ibm.jtc.demos;

/**
 * A demonstration application designed to leak native memory.
 *
 * @author <a href="mailto:andhall@uk.ibm.com">Andrew Hall</a>
 *
 */
public class LeakyJNIApp
{
    
    /**
     * The default amount of memory to leak per call to nativeMethod.
     * 
     * Can be overridden on the command line.
     */
    public static int DEFAULT_AMOUNT_TO_LEAK_BYTES = 1024;
    
    /**
     * Time to sleep between calls to nativeMethod.
     */
    public static int SLEEP_TIME_MILLIS = 100;

    /**
     * JNI method that leaks memory
     * 
     * @param amountToLeak The number of bytes to leak. Should be > 0
     */
    private static native void nativeMethod(int amountToLeak);
    
    static
    {
        System.loadLibrary("leakyjniapp");
    }
    
    /**
     * Sits in a loop calling nativeMethod
     * @param args
     */
    public static void main(String[] args)
    {
        int amountToLeak = DEFAULT_AMOUNT_TO_LEAK_BYTES ;
	int timeToRunSeconds = -1;
        
        if(args.length > 0)
        {
            String durationSecondsStr = args[0];
            
            try
            {
                timeToRunSeconds = Integer.parseInt(durationSecondsStr);
            }
            catch(NumberFormatException ex)
            {
                System.err.println("Error: couldn't parse argument: " + amountToLeak 
                        + " as an integer.");
            }
        }

	long stopTimeMillis = (timeToRunSeconds == -1) ? Long.MAX_VALUE : System.currentTimeMillis() + 1000*timeToRunSeconds;
        
        while(System.currentTimeMillis() < stopTimeMillis)
        {
            nativeMethod(amountToLeak);
            
            snooze();
        }
    }

    private static void snooze()
    {
        try
        {
            Thread.sleep(SLEEP_TIME_MILLIS);
        }
        catch(InterruptedException ex)
        {
            //Ignore
        }
    }


    final String copyright = "(C) Copyright IBM Corp. 2008. All Rights Reserved. US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.";

}
