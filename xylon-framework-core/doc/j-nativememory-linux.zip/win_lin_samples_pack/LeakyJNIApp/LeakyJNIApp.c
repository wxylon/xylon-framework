#include <stdio.h>
#include <stdlib.h>
#include <jni.h>

#include "com_ibm_jtc_demos_LeakyJNIApp.h"

/*
 * DeveloperWorks Native Memory Article Sample Code
 * (C) Copyright IBM Corp. 2008. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or
 * disclosure restricted by GSA ADP Schedule Contract with
 * IBM Corp.
 */

#define RUNTIME_EXCEPTION "java/lang/RuntimeException"

#define BUF_SIZE 100

const char copyright[] = "(C) Copyright IBM Corp. 2008. All Rights Reserved. \
US Government Users Restricted Rights - Use, duplication or \
disclosure restricted by GSA ADP Schedule Contract with \
IBM Corp. ";
 

static void throw_invalid_amount_exception(JNIEnv * env,jint amount_to_leak)
{
	jclass exception_class;
	jint err;
	char message_buffer [BUF_SIZE];
	
	exception_class = (*env)->FindClass(env,RUNTIME_EXCEPTION);
	
	if(NULL == exception_class)
	{
		/*Couldn't load the exception class. An exception will have been thrown so return*/
		return;
	}
	
	sprintf(message_buffer,"Error: supplied amountToLeak %d must be > 0",amount_to_leak);
	
	err = (*env)->ThrowNew(env,exception_class,message_buffer);
	
	return;
}

/*
 * JNI function that leaks a specified amount of native memory
 */
JNIEXPORT void JNICALL Java_com_ibm_jtc_demos_LeakyJNIApp_nativeMethod
  (JNIEnv * env, jclass clazz, jint amount_to_leak)
{
	void * ptr;
	if(amount_to_leak <= 0)
	{
		throw_invalid_amount_exception(env,amount_to_leak);
		
		return;	
	}
	
	ptr = malloc((size_t)amount_to_leak);
	
	/*Now leave without freeing ptr*/
	return;
}
